import { ConsoleLogger, Injectable } from '@nestjs/common';
import { exec } from 'child_process';
import * as util from 'util';

interface KeysResponse {
  derivationPath: string;
  mnemonic: string;
  private: string;
  public: string;
}

export interface WalletCreated {
  address: string;
  keyIndex: number;
  privateKey: string;
  publicKey: string;
  mnemonic: string;
  derivationPath: string;
}

@Injectable()
export class CreateWalletUseCase {
  logger: ConsoleLogger;

  constructor() {
    this.logger = new ConsoleLogger(CreateWalletUseCase.name);
  }

  async main(): Promise<WalletCreated> {
    const { stdout: stdoutKeys, stderr: stderrKeys } = await util.promisify(
      exec,
    )(`flow keys generate --sig-algo ECDSA_secp256k1 -o json`);

    if (stderrKeys) {
      this.logger.error(stderrKeys);
      throw new Error(stderrKeys);
    }

    const keys: KeysResponse = JSON.parse(stdoutKeys);

    const { stdout: stdoutWallet, stderr: stderrWallet } = await util.promisify(
      exec,
    )(
      `flow accounts create --key ${keys.public} --sig-algo ECDSA_secp256k1 --signer emulator-account -o json`,
    );

    if (stderrWallet) {
      this.logger.error(stderrWallet);
      throw new Error(stderrWallet);
    }

    const walletCreated = JSON.parse(stdoutWallet);

    return {
      address: walletCreated.address,
      keyIndex: walletCreated.keyIndex,
      privateKey: keys.private,
      publicKey: keys.public,
      mnemonic: keys.mnemonic,
      derivationPath: keys.derivationPath,
    };
  }
}
