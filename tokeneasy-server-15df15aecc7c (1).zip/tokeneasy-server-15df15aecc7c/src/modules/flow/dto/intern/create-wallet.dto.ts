type Key = {
  index: number;
  type: 'local';
  publicKey: string;
  signAlgo: string;
  hashAlgo: string;
  createdAt: Date;
  updatedAt: Date;
};
export type CreateWalletResponseAxios = {
  address: string;
  keys: Array<Key>;
  type: 'custodial';
  createdAt: Date;
  updatedAt: Date;
};
