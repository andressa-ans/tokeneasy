import axios from 'axios';

export const api = axios.create({
  baseURL: 'http://localhost:3000/v1/',
});

export type ServerError = {
  isError: boolean;
  message: string;
};

export const handleError = (errorMessage: string): ServerError => {
  return {
    isError: true,
    message: errorMessage,
  };
};
