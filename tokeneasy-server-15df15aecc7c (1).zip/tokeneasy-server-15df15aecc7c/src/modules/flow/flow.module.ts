import * as dotenv from 'dotenv';
dotenv.config();

import { Module } from '@nestjs/common';
import { CreateWalletUseCase } from './usecase/create-wallet.flow';
@Module({
  imports: [],
  providers: [CreateWalletUseCase],
  exports: [CreateWalletUseCase],
})
export class FlowModule {}
