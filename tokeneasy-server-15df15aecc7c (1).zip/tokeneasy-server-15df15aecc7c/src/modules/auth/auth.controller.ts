import { Body, Controller, Post } from '@nestjs/common';
import { LoginAuthRequestDTO } from './dto/request/login-auth.dto';
import { LoginAuthResponseDTO } from './dto/response/login-auth.dto';
import { LoginAuthUseCase } from './usecase/login.auth';
import { RegisterAuthRequestDTO } from './dto/request/register-auth.dto';
import { RegisterAuthResponseDTO } from './dto/response/register-auth.dto';
import { RegisterAuthUseCase } from './usecase/register.auth';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly loginAuthUseCase: LoginAuthUseCase,
    private readonly registerAuthUseCase: RegisterAuthUseCase,
  ) {}

  @Post('login')
  async login(
    @Body() body: LoginAuthRequestDTO,
  ): Promise<LoginAuthResponseDTO> {
    return this.loginAuthUseCase.main(body);
  }

  @Post('register')
  async register(
    @Body() body: RegisterAuthRequestDTO,
  ): Promise<RegisterAuthResponseDTO> {
    return this.registerAuthUseCase.main(body);
  }
}
