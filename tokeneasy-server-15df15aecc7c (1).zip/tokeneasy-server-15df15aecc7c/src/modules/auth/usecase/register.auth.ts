import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateUserUseCase } from 'src/modules/user/usecase/create.user';
import { RegisterAuthRequestDTO } from '../dto/request/register-auth.dto';
import { RegisterAuthResponseDTO } from '../dto/response/register-auth.dto';
import { LoginAuthUseCase } from './login.auth';

@Injectable()
export class RegisterAuthUseCase {
  constructor(
    private readonly createUserUseCase: CreateUserUseCase,
    private readonly loginAuthUseCase: LoginAuthUseCase,
  ) {}

  async main(body: RegisterAuthRequestDTO): Promise<RegisterAuthResponseDTO> {
    const newUser = await this.createUserUseCase.main(body).catch(() => {
      throw new InternalServerErrorException(
        'Ops, there was an error on create user',
      );
    });

    const userLogged = await this.loginAuthUseCase.main({
      email: body.email,
      password: body.password,
    });

    return { _id: newUser._id, access_token: userLogged.access_token };
  }
}
