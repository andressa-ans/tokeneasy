import { Injectable, NotAcceptableException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { FindByEmailUserUseCase } from 'src/modules/user/usecase/find-by-email.user';
import { LoginAuthRequestDTO } from '../dto/request/login-auth.dto';
import { LoginAuthResponseDTO } from '../dto/response/login-auth.dto';
import { SignTokenAuthUseCase } from './sign-token.auth';

@Injectable()
export class LoginAuthUseCase {
  constructor(
    private readonly findByEmailUserUseCase: FindByEmailUserUseCase,
    private signTokenAuthUseCase: SignTokenAuthUseCase,
  ) {}

  async main(body: LoginAuthRequestDTO): Promise<LoginAuthResponseDTO> {
    const user = await this.findByEmailUserUseCase.main({ email: body.email });

    if (!user) return null;
    const passwordValid = await bcrypt.compare(body.password, user.password);

    if (!user) {
      throw new NotAcceptableException('could not find the user');
    }
    if (!passwordValid) {
      throw new NotAcceptableException('incorrect password');
    }
    const token = this.signTokenAuthUseCase.main({
      email: user.email,
      _id: user._id,
    });

    return { access_token: token };
  }
}
