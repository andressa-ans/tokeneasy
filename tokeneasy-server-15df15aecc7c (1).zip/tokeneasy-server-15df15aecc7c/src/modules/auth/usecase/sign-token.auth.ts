import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

interface SignTokenInterface {
  email: string;
  _id: string;
}

@Injectable()
export class SignTokenAuthUseCase {
  constructor(private jwtService: JwtService) {}

  main(sign: SignTokenInterface): string {
    const payload = {
      email: sign.email,
      sub: sign._id,
    };

    return this.jwtService.sign(payload);
  }
}
