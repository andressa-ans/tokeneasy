import { Injectable, UnauthorizedException } from '@nestjs/common';
import { User } from 'src/entity/users.entity';
import { JwtPayload } from '../dto/intern/jwt-payload.interface';
import { FindByEmailUserUseCase } from 'src/modules/user/usecase/find-by-email.user';

@Injectable()
export class VerifyPayloadAuthUseCase {
  constructor(private findByEmailUserUseCase: FindByEmailUserUseCase) {}

  async main(payload: JwtPayload): Promise<User> {
    const user = await this.findByEmailUserUseCase.main({
      email: payload.email,
    });
    if (user) {
      return new User(user);
    }

    throw new UnauthorizedException(`Could not find the user`);
  }
}
