import { IsNotEmpty, IsString } from 'class-validator';

export class RegisterAuthResponseDTO {
  @IsString()
  @IsNotEmpty()
  _id: string;

  @IsString()
  @IsNotEmpty()
  access_token: string;
}
