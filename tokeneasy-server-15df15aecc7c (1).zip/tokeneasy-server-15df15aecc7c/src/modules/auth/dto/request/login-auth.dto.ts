import { IsNotEmpty, IsString } from 'class-validator';

export class LoginAuthRequestDTO {
  @IsString()
  @IsNotEmpty()
  email: string;

  @IsString()
  @IsNotEmpty()
  password: string;
}
