import * as dotenv from 'dotenv';
dotenv.config();
import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Users, UsersSchema } from 'src/database/users.mongodb';
import { PassportModule } from '@nestjs/passport';
import { UserRepository } from 'src/infra/users.repository';
import { JwtModule } from '@nestjs/jwt';
import { UserModule } from '../user/user.module';
import { SessionSerializer } from './config/session.serializer';
import { JwtStrategy } from './config/jwt.strategy';
import { LoginAuthUseCase } from './usecase/login.auth';
import { SignTokenAuthUseCase } from './usecase/sign-token.auth';
import { VerifyPayloadAuthUseCase } from './usecase/verify-payload.auth';
import { RegisterAuthUseCase } from './usecase/register.auth';
@Module({
  controllers: [AuthController],
  imports: [
    PassportModule.register({ defaultStrategy: 'jwt' }),
    UserModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '1d' },
    }),
    MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
  ],
  providers: [
    UserRepository,
    SessionSerializer,
    JwtStrategy,
    LoginAuthUseCase,
    SignTokenAuthUseCase,
    VerifyPayloadAuthUseCase,
    RegisterAuthUseCase,
  ],
})
export class AuthModule {}
