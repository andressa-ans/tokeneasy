import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { VerifyPayloadAuthUseCase } from '../usecase/verify-payload.auth';
import { JwtPayload } from '../dto/intern/jwt-payload.interface';
import { User } from 'src/entity/users.entity';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(
    private readonly verifyPayloadAuthUseCase: VerifyPayloadAuthUseCase,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: process.env.JWT_SECRET,
      ignoreExpiration: false,
      passReqToCallback: false,
    });
  }

  async validate(payload: JwtPayload): Promise<User> {
    return await this.verifyPayloadAuthUseCase.main(payload);
  }
}
