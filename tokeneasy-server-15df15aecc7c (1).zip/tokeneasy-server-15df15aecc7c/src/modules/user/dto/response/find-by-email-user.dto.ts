import { IsNotEmpty, IsString } from 'class-validator';

class FlowWallet {
  @IsString()
  @IsNotEmpty()
  address: string;

  @IsString()
  @IsNotEmpty()
  publicKey: string;

  @IsString()
  @IsNotEmpty()
  privateKey: string;

  @IsString()
  @IsNotEmpty()
  mnemonic: string;

  @IsString()
  @IsNotEmpty()
  derivationPath: string;
}
export class FindByEmailUserResponseDTO {
  @IsString()
  @IsNotEmpty()
  fullname: string;

  @IsString()
  @IsNotEmpty()
  email: string;

  @IsString()
  @IsNotEmpty()
  profilePhoto: string;

  @IsString()
  @IsNotEmpty()
  _id: string;

  @IsString()
  @IsNotEmpty()
  password: string;

  @IsNotEmpty()
  flowWallet: FlowWallet;
}
