import { IsNotEmpty, IsString } from 'class-validator';

export class CreateUserResponseDTO {
  @IsString()
  @IsNotEmpty()
  _id: string;
}
