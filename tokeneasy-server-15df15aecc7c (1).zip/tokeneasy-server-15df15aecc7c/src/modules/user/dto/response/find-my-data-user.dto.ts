import { IsNotEmpty, IsString } from 'class-validator';

export class FindMyDataUserResponseDTO {
  @IsString()
  @IsNotEmpty()
  fullname: string;

  @IsString()
  @IsNotEmpty()
  email: string;

  @IsString()
  @IsNotEmpty()
  profilePhoto: string;

  @IsString()
  @IsNotEmpty()
  _id: string;
}
