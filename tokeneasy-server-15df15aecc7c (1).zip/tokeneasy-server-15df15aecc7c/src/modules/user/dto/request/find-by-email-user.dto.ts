import { IsNotEmpty, IsString } from 'class-validator';

export class FindByEmailUserRequestDTO {
  @IsString()
  @IsNotEmpty()
  email: string;
}
