import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { UserRepository } from 'src/infra/users.repository';
import { FindMyDataUserResponseDTO } from '../dto/response/find-my-data-user.dto';

@Injectable()
export class FindMyDataUserUseCase {
  constructor(private readonly repository: UserRepository) {}

  async main(_id: string): Promise<FindMyDataUserResponseDTO> {
    const user = await this.repository.findById({ _id }).catch((error) => {
      console.log(error);
      throw new InternalServerErrorException(
        'Ops, there was an error your read user',
      );
    });

    return {
      _id: user._id,
      email: user.email,
      fullname: user.fullname,
      profilePhoto: user.profilePhoto,
    };
  }
}
