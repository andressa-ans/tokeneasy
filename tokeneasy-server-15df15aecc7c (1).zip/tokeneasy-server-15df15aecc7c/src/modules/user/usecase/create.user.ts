import { ConsoleLogger, Injectable } from '@nestjs/common';
import { User } from 'src/entity/users.entity';
import { setupAccountTx } from 'src/helpers/flowTransaction';
import { UserRepository } from 'src/infra/users.repository';
import { CreateWalletUseCase } from 'src/modules/flow/usecase/create-wallet.flow';
import { CreateUserRequestDTO } from '../dto/request/create-user.dto';
import { CreateUserResponseDTO } from '../dto/response/create-user.dto';

@Injectable()
export class CreateUserUseCase {
  logger: ConsoleLogger;

  constructor(
    private readonly repository: UserRepository,
    private readonly createWalletUseCase: CreateWalletUseCase,
  ) {
    this.logger = new ConsoleLogger(CreateUserUseCase.name);
  }

  async main(body: CreateUserRequestDTO): Promise<CreateUserResponseDTO> {
    this.logger.log(`body:: ${JSON.stringify(body)}`);

    const userEntity = new User({ ...body });

    await userEntity.transformHashPassword();

    let user = await this.repository.save(userEntity).catch((error) => {
      this.logger.error(error);
      throw error;
    });

    userEntity._id = user._id;

    const createWallet = await this.createWalletUseCase
      .main()
      .catch((error) => {
        this.repository.remove({
          _id: user._id,
        });
        this.logger.error(error);
        throw error;
      });

    userEntity.flowWallet = {
      address: createWallet.address,
      privateKey: createWallet.privateKey,
      publicKey: createWallet.publicKey,
      mnemonic: createWallet.mnemonic,
      derivationPath: createWallet.derivationPath,
    };

    user = await this.repository.save(userEntity).catch((error) => {
      this.logger.error(error);
      throw error;
    });

    await setupAccountTx({
      address: createWallet.address,
      privateKey: createWallet.privateKey,
    });

    return user;
  }
}
