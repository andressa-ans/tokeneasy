import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { UserRepository } from 'src/infra/users.repository';
import { FindByEmailUserRequestDTO } from '../dto/request/find-by-email-user.dto';
import { FindByEmailUserResponseDTO } from '../dto/response/find-by-email-user.dto';

@Injectable()
export class FindByEmailUserUseCase {
  constructor(private readonly repository: UserRepository) {}

  async main(
    body: FindByEmailUserRequestDTO,
  ): Promise<FindByEmailUserResponseDTO> {
    const user = await this.repository
      .findByEmail({ email: body.email })
      .catch(() => {
        throw new InternalServerErrorException(
          'Ops, there was an error on read user',
        );
      });

    return {
      _id: user._id,
      email: user.email,
      fullname: user.fullname,
      profilePhoto: user.profilePhoto,
      password: user.password,
      flowWallet: user.flowWallet,
    };
  }
}
