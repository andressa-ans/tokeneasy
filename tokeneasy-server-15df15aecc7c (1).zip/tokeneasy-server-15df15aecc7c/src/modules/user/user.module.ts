import { Module } from '@nestjs/common';
import { UserController } from './user.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Users, UsersSchema } from 'src/database/users.mongodb';
import { CreateUserUseCase } from './usecase/create.user';
import { UserRepository } from 'src/infra/users.repository';
import { FindByEmailUserUseCase } from './usecase/find-by-email.user';
import { FindMyDataUserUseCase } from './usecase/find-my-data.user';
import { CreateWalletUseCase } from '../flow/usecase/create-wallet.flow';

@Module({
  controllers: [UserController],
  imports: [
    MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
  ],
  providers: [
    CreateUserUseCase,
    FindByEmailUserUseCase,
    FindMyDataUserUseCase,
    UserRepository,
    CreateWalletUseCase,
  ],
  exports: [FindByEmailUserUseCase, CreateUserUseCase],
})
export class UserModule {}
