import { Controller, Get, UseGuards } from '@nestjs/common';
import { User } from 'src/entity/users.entity';
import { JWTAuthGuard } from '../auth/config/jwt-auth.guard';
import { SessionAuthGuard } from '../auth/config/session-auth.guard';
import { AuthUser } from './decorators/user.decorator';
import { CreateUserResponseDTO } from './dto/response/create-user.dto';
import { FindMyDataUserUseCase } from './usecase/find-my-data.user';

@Controller('user')
export class UserController {
  constructor(private readonly findMyDataUserUseCase: FindMyDataUserUseCase) {}

  @Get('me')
  @UseGuards(SessionAuthGuard, JWTAuthGuard)
  async me(@AuthUser() user: User): Promise<CreateUserResponseDTO> {
    return await this.findMyDataUserUseCase.main(user._id);
  }
}
