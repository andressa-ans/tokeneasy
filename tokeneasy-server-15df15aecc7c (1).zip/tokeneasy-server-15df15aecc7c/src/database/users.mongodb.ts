import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Exclude } from 'class-transformer';
import { Document } from 'mongoose';

@Schema({ _id: false })
export class FlowWallet extends Document {
  @Prop({ required: true })
  address: string;

  @Prop({ required: true })
  publicKey: string;

  @Prop({ required: true })
  privateKey: string;

  @Prop({ required: true })
  mnemonic: string;

  @Prop({ required: true })
  derivationPath: string;
}
const FlowWalletSchemaLocally = SchemaFactory.createForClass(FlowWallet);

@Schema({ timestamps: true })
export class Users extends Document {
  @Prop({ required: true })
  fullname: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ default: null })
  profilePhoto: string;

  @Prop({ default: null, type: FlowWalletSchemaLocally })
  flowWallet: FlowWallet;

  @Prop({ required: true })
  @Exclude()
  password: string;

  @Prop({ default: false })
  deleted: boolean;
}
const UsersSchemaLocally = SchemaFactory.createForClass(Users);

export const UsersSchema = UsersSchemaLocally;
