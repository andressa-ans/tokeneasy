declare global {
  namespace NodeJS {
    interface ProcessEnv {
      NODE_ENV: 'development' | 'production';
      JWT_SECRET: string;
      JWT_REFRESH_SECRET: string;
      URL_CONNECTION_MONGODB: string;
      DB_NAME_MONGODB: string;
      APP_PORT: string;
      FLOW_API_URL: string;
    }
  }
}

export {};
