import * as bcrypt from 'bcryptjs';

type FlowWallet = {
  address: string;
  privateKey: string;
  publicKey: string;
  mnemonic: string;
  derivationPath: string;
};

export type UserType = {
  _id?: string;
  fullname: string;
  email: string;
  flowWallet?: FlowWallet;
  profilePhoto?: string;
  password?: string;
  deleted?: boolean;
};

export class User {
  public _id?: string;
  public fullname: string;
  public email: string;
  public flowWallet?: FlowWallet;
  public profilePhoto?: string;
  public password?: string;
  public deleted: boolean;

  constructor(data: UserType) {
    this._id = data._id ? String(data._id) : undefined;
    this.fullname = data.fullname;
    this.email = data.email;
    this.flowWallet = data.flowWallet ?? undefined;
    this.profilePhoto = data.profilePhoto ?? undefined;
    this.password = data.password ?? undefined;
    this.deleted = data.deleted ?? undefined;
  }

  async transformHashPassword() {
    this.password = await bcrypt.hash(this.password, 10);
  }
}

export interface UserRepositoryInterface {
  save: (
    input: UserRepositoryInterface.SaveInput,
  ) => Promise<UserRepositoryInterface.SaveOutput>;

  findById: (
    input: UserRepositoryInterface.FindByIdInput,
  ) => Promise<UserRepositoryInterface.FindByIdOutput>;

  findByEmail: (
    input: UserRepositoryInterface.FindByEmailInput,
  ) => Promise<UserRepositoryInterface.FindByEmailOutput>;

  remove: (
    input: UserRepositoryInterface.RemoveInput,
  ) => Promise<UserRepositoryInterface.RemoveOutput>;
}
export namespace UserRepositoryInterface {
  export type SaveInput = User;
  export type SaveOutput = { _id: string };

  export type FindByIdInput = { _id: string };
  export type FindByIdOutput = User;

  export type FindByEmailInput = { email: string };
  export type FindByEmailOutput = User;

  export type RemoveInput = { _id: string };
  export type RemoveOutput = void;
}
