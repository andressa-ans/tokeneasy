import { sansPrefix, withPrefix } from '@onflow/util-address';
import { SHA3 } from 'sha3';

import { ec as EC } from 'elliptic';

const ec = new EC('secp256k1');

const sign = (message, privateKey) => {
  const key = ec.keyFromPrivate(Buffer.from(privateKey, 'hex'));
  const sig = key.sign(hash(message));
  const n = 32;
  const r = sig.r.toArrayLike(Buffer, 'be', n);
  const s = sig.s.toArrayLike(Buffer, 'be', n);
  return Buffer.concat([r, s]).toString('hex');
};

const hash = (message) => {
  const sha = new SHA3(256);
  sha.update(Buffer.from(message, 'hex'));
  return sha.digest();
};

const authorizationFunction = async (account, { address, privateKey }) => {
  console.log('account', account);
  console.log('address', address);
  console.log('privateKey', privateKey);
  console.log('sansPrefix(address)', sansPrefix(address));
  console.log('withPrefix(address)', withPrefix(address));
  return {
    ...account,
    tempId: `${address}-${0}`,
    addr: sansPrefix(address),
    keyId: 0,
    signingFunction: async (signable) => {
      return {
        addr: withPrefix(address),
        keyId: 0,
        signature: sign(signable.message, privateKey),
      };
    },
  };
};

export default authorizationFunction;
