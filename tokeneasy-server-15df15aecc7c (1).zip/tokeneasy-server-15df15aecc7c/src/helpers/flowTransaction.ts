import authorizationFunction from './flowAuthorizer';

import * as fcl from '@onflow/fcl';
import * as t from '@onflow/types';

fcl.config().put('accessNode.api', 'http://127.0.0.1:8888');

const setupAccountTx = async ({ privateKey, address }) => {
  console.log('Sending Tx');
  const transactionId = await fcl
    .send([
      fcl.transaction`
        import SecurityToken from 0xf8d6e0586b0a20c7
        import ExampleToken from 0xf8d6e0586b0a20c7

        transaction () {

            prepare(signer: AuthAccount) {

                // Return early if the account already stores a ExampleToken Vault
                if signer.borrow<&ExampleToken.Vault>(from: ExampleToken.VaultStoragePath) != nil {
                    log("Account already has a ExampleToken Vault")
                    return
                }

                // Create a new ExampleToken Vault and put it in storage
                signer.save(
                    <-ExampleToken.createEmptyVault(),
                    to: ExampleToken.VaultStoragePath
                )

                // Create a public capability to the Vault that only exposes
                // the deposit function through the Receiver interface
                signer.link<&ExampleToken.Vault{SecurityToken.Receiver}>(
                    ExampleToken.ReceiverPublicPath,
                    target: ExampleToken.VaultStoragePath
                )

                // Create a public capability to the Vault that exposes the Balance interface
                signer.link<&ExampleToken.Vault{SecurityToken.Balance}>(
                    ExampleToken.VaultPublicPath,
                    target: ExampleToken.VaultStoragePath
                )

                log("ExampleToken Vault created and stored in account")
            }
        }
      `,
      fcl.proposer((acc) =>
        authorizationFunction(acc, {
          address,
          privateKey,
        }),
      ),
      fcl.payer((acc) =>
        authorizationFunction(acc, {
          address,
          privateKey,
        }),
      ),
      fcl.authorizations([
        (acc) =>
          authorizationFunction(acc, {
            address,
            privateKey,
          }),
      ]),
      fcl.limit(9999),
    ])
    .then(fcl.decode)
    .catch((error) => {
      console.log(error);
      throw new Error('Error sending transaction');
    });

  console.log(transactionId);
};

export { setupAccountTx };
