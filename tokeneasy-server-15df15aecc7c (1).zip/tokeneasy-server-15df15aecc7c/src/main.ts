import {
  BadRequestException,
  ConsoleLogger,
  ValidationPipe,
} from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { ValidationError } from 'class-validator';
import * as session from 'express-session';
import * as passport from 'passport';
import { AppModule } from './app.module';

async function bootstrap() {
  const logger = new ConsoleLogger('Application');

  const app = await NestFactory.create(AppModule);

  //For login session
  app.use(
    session({
      secret: process.env.JWT_SECRET,
      resave: false,
      saveUninitialized: false,
      store: new session.MemoryStore(),
      cookie: {
        httpOnly: true,
        signed: true,
        sameSite: 'strict',
        secure: process.env.NODE_ENV === 'production',
      },
    }),
  );
  app.use(passport.initialize());
  app.use(passport.session());

  //Use for validation body requests
  app.useGlobalPipes(
    new ValidationPipe({
      exceptionFactory: (errors: ValidationError[]) => {
        const errorMsg: string[] = [];
        errors.forEach((e: any) => {
          errorMsg.push(Object.values(e.constraints).join());
        });
        return new BadRequestException(
          'Validation error: ' + errorMsg.join(', '),
          'validation_error',
        );
      },
    }),
  );

  //Listen application
  await app.listen(process.env.APP_PORT);

  logger.log(`Listening at http://localhost:${process.env.APP_PORT}`);
}
bootstrap();
