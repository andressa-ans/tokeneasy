import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Users } from 'src/database/users.mongodb';
import { User, UserRepositoryInterface } from 'src/entity/users.entity';

@Injectable()
export class UserRepository implements UserRepositoryInterface {
  constructor(
    @InjectModel(Users.name)
    private readonly model: Model<Users>,
  ) {}

  async save(input: User): Promise<UserRepositoryInterface.SaveOutput> {
    if (input._id) return this._update(input);
    else return this._create(input);
  }

  private async _create(
    input: User,
  ): Promise<UserRepositoryInterface.SaveOutput> {
    const { _id } = await this.model.create(input).catch((error) => {
      throw error;
    });

    return { _id };
  }

  private async _update(
    input: User,
  ): Promise<UserRepositoryInterface.SaveOutput> {
    const { _id } = await this.model
      .findByIdAndUpdate(input._id, input)
      .catch((error) => {
        throw error;
      });

    return { _id };
  }

  async findById(
    input: UserRepositoryInterface.FindByIdInput,
  ): Promise<UserRepositoryInterface.FindByIdOutput> {
    const result = await this.model.findById(input._id).catch((error) => {
      console.log(error);
      throw error;
    });

    return new User(result);
  }

  async findByEmail(
    input: UserRepositoryInterface.FindByEmailInput,
  ): Promise<UserRepositoryInterface.FindByEmailOutput> {
    const result = await this.model
      .findOne({ email: input.email })
      .catch((error) => {
        throw error;
      });

    if (!result) return null;
    return new User(result);
  }

  async remove(
    input: UserRepositoryInterface.RemoveInput,
  ): Promise<UserRepositoryInterface.RemoveOutput> {
    await this.model.findByIdAndDelete(input._id).catch((error) => {
      throw error;
    });
  }
}
