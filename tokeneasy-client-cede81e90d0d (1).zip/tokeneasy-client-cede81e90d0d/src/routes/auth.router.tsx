import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Home from "@screens/Auth/Home";
import Login from "@screens/Auth/Login";
import Register from "@screens/Auth/Register";

const { Navigator, Screen } = createNativeStackNavigator();

export function AuthRoutes() {
  return (
    <Navigator screenOptions={{ headerShown: false }}>
      <Screen name="Home" component={Home} />
      <Screen name="Login" component={Login} />
      <Screen name="Register" component={Register} />
    </Navigator>
  );
}
