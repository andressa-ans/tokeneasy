import { NavigationContainer } from "@react-navigation/native";
import { AuthRoutes } from "./auth.router";

export function Routes() {
  return (
    <NavigationContainer>
      <AuthRoutes />
    </NavigationContainer>
  );
}
