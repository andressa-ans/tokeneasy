import handleColor from "@utils/handleColor";
import styled, { css } from "styled-components/native";

interface PropsText {
  bold?: boolean;
  width?: string;
  color?: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl";
  textAlign?: "center" | "left" | "right" | "justify";
  wrap?: boolean;
}

export const Text = styled.Text<PropsText>`
  ${({ wrap }) =>
    wrap
      ? css`
          flex: 1;
          flex-wrap: wrap;
        `
      : null}

  text-align: ${({ textAlign }) => (textAlign ? textAlign : "left")};

  font-family: ${({ bold, theme }) =>
    bold ? theme.fonts.bold : theme.fonts.regular};

  font-size: ${({ size, theme }) =>
    size ? theme.fontSizes[size] : theme.fontSizes.md};

  color: ${({ color, theme }) =>
    color ? handleColor(color) : theme.colors.black};

  width: ${({ width }) => (width ? width : "auto")};
`;
