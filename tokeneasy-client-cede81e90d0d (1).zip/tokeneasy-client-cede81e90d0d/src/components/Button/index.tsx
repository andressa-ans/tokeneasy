import { Text } from "@components/Typography";
import { TouchableOpacityProps } from "react-native";
import { StyledButton } from "./styled";

interface IButton extends TouchableOpacityProps {
  fullwidth?: boolean;
  label?: string;
  color?: string;
  children?: any;
}

export default function Button({ children, color, label, ...props }: IButton) {
  return (
    <StyledButton color={color} {...props}>
      {!!children ? (
        children
      ) : (
        <Text bold color="white">
          {label}
        </Text>
      )}
    </StyledButton>
  );
}
