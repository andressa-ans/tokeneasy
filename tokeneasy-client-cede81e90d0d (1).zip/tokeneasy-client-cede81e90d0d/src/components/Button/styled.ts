import handleColor from "@utils/handleColor";
import styled from "styled-components/native";

interface ButtonProps {
  color?: string;
  fullwidth?: boolean;
}

export const StyledButton = styled.TouchableOpacity<ButtonProps>`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;

  width: ${({ fullwidth }) => (fullwidth ? "100%" : "auto")};
  height: 48px;
  padding: 10px 16px;

  border-radius: 4px;

  background-color: ${({ color, theme }) =>
    color ? handleColor(color) : theme.colors.primary};
`;
