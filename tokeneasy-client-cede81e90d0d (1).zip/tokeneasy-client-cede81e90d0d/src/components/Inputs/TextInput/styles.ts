import styled, { css } from "styled-components/native";
import { Animated } from "react-native";

export const Container = styled.View<{ fullWidth: boolean }>`
  width: ${({ fullWidth }) => (fullWidth ? "100%" : "auto")};
`;

export const Label = styled.Text``;

export const Input = styled.TextInput`
  height: 48px;
  padding: 0 16px;

  border: 1px solid #919eab;
  border-radius: 4px;
`;
