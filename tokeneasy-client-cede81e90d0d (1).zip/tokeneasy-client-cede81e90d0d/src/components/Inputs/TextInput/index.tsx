import { Container, Input, Label } from "./styles";
import { TextInputProps, Animated } from "react-native";
import { useState, useRef } from "react";

interface InputProps extends TextInputProps {
  label: string;
  fullWidth?: boolean;
}

export default function TextInput({ label, fullWidth, ...props }: InputProps) {
  return (
    <Container fullWidth={fullWidth}>
      <Label>{label}</Label>
      <Input {...props} />
    </Container>
  );
}
