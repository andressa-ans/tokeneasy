import { Container } from "./styles";
import Icon from "react-native-vector-icons/AntDesign";
import { TouchableOpacity } from "react-native";
import { Text } from "@components/Typography";

interface Props {
  name: string;
  navigation: any;
}

export default function TopBar({ name, navigation }: Props) {
  return (
    <Container>
      <TouchableOpacity
        onPress={() => {
          navigation.goBack();
        }}
      >
        <Icon name="arrowleft" size={32} />
      </TouchableOpacity>
      <Text size="xl" bold>
        {name}
      </Text>
    </Container>
  );
}
