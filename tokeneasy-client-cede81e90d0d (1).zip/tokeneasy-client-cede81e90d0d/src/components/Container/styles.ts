import styled from "styled-components/native";

interface IContainer {
  direction?: "row" | "column";
  gap?: string;
  justify?: string;
  align?: string;
}

export const StyledContainer = styled.View<IContainer>`
  display: flex;
  flex-direction: ${({ direction }) => (direction ? direction : "column")};
  justify-content: ${({ justify }) => (justify ? justify : "flex-start")};
  align-items: ${({ align }) => (align ? align : "center")};
  gap: ${({ gap }) => (gap ? gap : 0)};
  width: 100%;
`;
