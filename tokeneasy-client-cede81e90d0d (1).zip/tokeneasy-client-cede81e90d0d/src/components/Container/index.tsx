import { StyledContainer } from "./styles";

interface IContainer {
  direction?: "row" | "column";
  gap?: string;
  children?: any;
}

export default function Container({ children, ...props }: IContainer) {
  return <StyledContainer {...props}>{children}</StyledContainer>;
}
