import theme from "@theme/index";

export default function handleColor(color: string) {
  const themeColor = color.split(".").reduce((previous, current) => {
    return previous[current];
  }, theme.colors);

  return themeColor;
}
