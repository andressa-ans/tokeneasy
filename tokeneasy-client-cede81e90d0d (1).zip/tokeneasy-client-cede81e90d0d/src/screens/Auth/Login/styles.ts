import styled from "styled-components/native";

export const Screen = styled.View`
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
`;
