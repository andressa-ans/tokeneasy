import { Screen } from "./styles";
import TextInput from "@components/Inputs/TextInput";
import TopBar from "@components/TopBar";
import Button from "@components/Button";
import Container from "@components/Container";

export default function LoginScreen({ navigation }) {
  return (
    <Screen>
      <TopBar navigation={navigation} name="Login Token Exchanger" />
      <Container gap="70px">
        <Container gap="10px">
          <TextInput
            placeholder="E-mail / Phone Number"
            label="E-mail / Phone Number"
            fullWidth
          />
          <TextInput
            secureTextEntry
            placeholder="Password"
            label="Password"
            fullWidth
          />
        </Container>
        <Button label="Next" color="secondary" fullwidth />
      </Container>
    </Screen>
  );
}
