import styled from "styled-components/native";

export const Container = styled.View`
  flex: 1;
  justify-content: space-evenly;
  align-items: center;
  padding: 16px;
`;

export const InfoButton = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 200px;

  padding: 8px 0px;
`;

export const Flex = styled.View`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
`;
