import { StyleSheet, View, Image, TouchableOpacity } from "react-native";
import { Container, Flex, InfoButton } from "./styles";
import { Text } from "@components/Typography";
import Button from "@components/Button";

import MCIcon from "react-native-vector-icons/MaterialCommunityIcons";
import Entypo from "react-native-vector-icons/Entypo";

import ImageHome from "@assets/images/home-image.png";

export default function Home({ navigation }) {
  return (
    <>
      <Container>
        <View
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Text bold size="xl">
            Welcome to Token Easy
          </Text>
          <Text>Buy chips easily and securely!</Text>
        </View>

        <View>
          <Image source={ImageHome} />
          <View style={styles.buttonGroup}>
            <Button
              style={{ width: "50%" }}
              color="secondary"
              label="Register"
              onPress={() => {
                navigation.navigate("Register");
              }}
            />
            <Button
              style={{ width: "50%" }}
              label="Login"
              onPress={() => {
                navigation.navigate("Login");
              }}
            />
          </View>
        </View>

        <View>
          <InfoButton>
            <Flex>
              <MCIcon color="#737373" name="web" size={30} />
              <Text color="grey">Idioma</Text>
            </Flex>
            <Entypo color="#737373" name="chevron-thin-right" size={20} />
          </InfoButton>
          <InfoButton>
            <Flex>
              <MCIcon color="#737373" name="information" size={30} />
              <Text color="grey">Ajuda & Suporte</Text>
            </Flex>
            <Entypo color="#737373" name="chevron-thin-right" size={20} />
          </InfoButton>
        </View>
      </Container>
    </>
  );
}

const styles = StyleSheet.create({
  buttonGroup: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    gap: 16,
    paddingHorizontal: "10%",
  },
  infoGroup: {},
});
