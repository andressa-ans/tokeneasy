import { useState } from "react";
import { Screen } from "./styles";
import CheckBox from "expo-checkbox";
import TextInput from "@components/Inputs/TextInput";
import TopBar from "@components/TopBar";
import Button from "@components/Button";
import Container from "@components/Container";
import { Text } from "@components/Typography";

export default function LoginScreen({ navigation }) {
  const [isChecked, setChecked] = useState(false);

  return (
    <Screen>
      <TopBar navigation={navigation} name="Create Account" />
      <Container gap="70px">
        <Container gap="10px">
          <TextInput placeholder="Name" label="Name" fullWidth />
          <TextInput placeholder="Email" label="Email" fullWidth />
          <TextInput placeholder="Phone" label="Phone" fullWidth />
          <TextInput
            secureTextEntry
            placeholder="Password"
            label="Password"
            fullWidth
          />
          <Container direction="row" gap="8px">
            <CheckBox value={isChecked} onValueChange={setChecked} />
            <Text wrap size="sm">
              I have read and agree to the Token Exchanger{" "}
              <Text size="sm" bold>
                Terms of Service
              </Text>{" "}
              and{" "}
              <Text size="sm" bold>
                Privacy Policy.
              </Text>
            </Text>
          </Container>
        </Container>
        <Button label="Register" color="secondary" fullwidth />
      </Container>
    </Screen>
  );
}
