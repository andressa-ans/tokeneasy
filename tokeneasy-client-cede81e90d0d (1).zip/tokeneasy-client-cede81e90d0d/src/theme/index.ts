export default {
  colors: {
    primary: "#45DD9F",
    secondary: "#0781D1",
    terciary: "#081E3F",

    error: { 100: "#FB9999", 200: "#F56363", 300: "#ED4848" },
    warning: { 100: "#FFE17F", 200: "#FFD139", 300: "#FFC400" },
    success: { 100: "#97ECA4", 200: "#76D585", 300: "#42C157" },

    white: "#FAFAFA",
    black: "#121212",

    grey: "#737373",
  },

  fonts: {
    regular: "Glacial Indifference",
    bold: "Glacial Indifference-Bold",
    italic: "Glacial Indifference-Italic",
  },

  fontSizes: {
    xs: "10px",
    sm: "12px",
    md: "16px",
    lg: "20px",
    xl: "24px",
    "2xl": "28px",
    "3xl": "32px",
    "4xl": "36px",
  },

  shadows: {
    base: `shadow-opacity: 0.8; shadow-color: #000; shadow-offset: 0px 1px; elevation: 3;`,
    md: `shadow-opacity: 0.8; shadow-color: #000; shadow-offset: 0px 4px; elevation: 5;`,
    ld: "shadow-opacity: 0.8; shadow-color: #000; shadow-offset: 0px 10px; elevation: 15;",
    xl: "shadow-opacity: 0.8; shadow-color: #000; shadow-offset: 0px 20px; elevation: 25;",
    xl2: "shadow-opacity: 0.8; shadow-color: #000; shadow-offset: 0px 25px; elevation: 50;",
  },
};
